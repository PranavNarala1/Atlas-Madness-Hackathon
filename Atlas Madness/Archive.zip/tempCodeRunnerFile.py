ee.Authenticate()
ee.Initialize()